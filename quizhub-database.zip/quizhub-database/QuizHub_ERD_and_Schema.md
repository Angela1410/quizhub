# QuizHub – ERD and Database Schema

## Entity-Relationship Diagram

```mermaid
erDiagram
    USERS ||--o{ QUIZZES : "creates (instructor)"
    USERS ||--o{ ATTEMPTS : "takes (student)"
    USERS ||--o{ ACTIVITY_LOGS : "generates"
    QUIZZES ||--o{ QUESTIONS : contains
    QUIZZES ||--o{ ATTEMPTS : "has"
    QUESTIONS ||--o{ OPTIONS : "has"
    ATTEMPTS ||--o{ ATTEMPT_ANSWERS : "records"
    QUESTIONS ||--o{ ATTEMPT_ANSWERS : "answered in"
    OPTIONS ||--o{ ATTEMPT_ANSWERS : "selected as"

    USERS {
        bigint id PK
        string name
        string email UK
        string password
        enum role "admin, instructor, student"
        boolean is_active
    }
    QUIZZES {
        bigint id PK
        bigint instructor_id FK
        string title
        text instructions
        enum status "draft, published, archived"
        datetime start_at
        datetime end_at
        int time_limit_minutes
        decimal passing_score
        int max_attempts
        enum result_visibility "immediate, after_close, hidden"
        boolean allow_review
    }
    QUESTIONS {
        bigint id PK
        bigint quiz_id FK
        enum type "multiple_choice, true_false"
        text question_text
        text feedback
        int points
        int position
    }
    OPTIONS {
        bigint id PK
        bigint question_id FK
        string option_text
        boolean is_correct
        int position
    }
    ATTEMPTS {
        bigint id PK
        bigint quiz_id FK
        bigint student_id FK
        int attempt_no
        enum status "in_progress, submitted, auto_submitted"
        datetime started_at
        datetime submitted_at
        decimal score
        decimal percentage
        boolean passed
    }
    ATTEMPT_ANSWERS {
        bigint id PK
        bigint attempt_id FK
        bigint question_id FK
        bigint option_id FK
        boolean is_correct
        decimal points_awarded
    }
    ACTIVITY_LOGS {
        bigint id PK
        bigint user_id FK
        string action
        text description
        string ip_address
    }
    SETTINGS {
        bigint id PK
        string key UK
        text value
    }
```

## Table summary

| Table | Purpose | Key constraints |
|---|---|---|
| users | Accounts for admin, instructor, student | `email` unique; `role` enum; `is_active` for deactivation |
| quizzes | Quiz settings: schedule, time limit, passing score, result visibility | `instructor_id` → users |
| questions | Multiple-choice and true/false questions | `quiz_id` → quizzes (cascade) |
| options | Answer choices; True/False uses two options | `question_id` → questions (cascade) |
| attempts | One row per student attempt, with timestamps and score | unique (`quiz_id`, `student_id`, `attempt_no`) |
| attempt_answers | Selected option per question, auto-graded | unique (`attempt_id`, `question_id`) |
| activity_logs | Platform activity for the admin report | `user_id` nullable |
| settings | Basic system settings (admin) | `key` unique |

## Notes
- Scoring: on submit, compare `attempt_answers.option_id` to the option with `is_correct = true`, set `points_awarded`, then compute `attempts.score`, `percentage`, and `passed` (percentage >= `quizzes.passing_score`).
- Attempt limit: block a new attempt when `attempt_no` would exceed `quizzes.max_attempts`.
- Deadline: reject answers when `now() > attempts.started_at + time_limit_minutes` or `now() > quizzes.end_at` (auto-submit).
- Normalization: all tables are in 3NF; question options are separated from questions so each option is atomic.
